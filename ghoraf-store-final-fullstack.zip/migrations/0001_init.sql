CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 category TEXT NOT NULL CHECK(category IN ('غرف نوم','مطابخ')),
 condition TEXT NOT NULL CHECK(condition IN ('جديد','مستعمل')),
 price TEXT DEFAULT '',
 city TEXT DEFAULT '',
 description TEXT DEFAULT '',
 image_key TEXT DEFAULT '',
 featured INTEGER DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_created ON products(created_at DESC);
