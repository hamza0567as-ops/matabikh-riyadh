const COOKIE = "ghoraf_admin";
const MAX_IMAGE = 8 * 1024 * 1024;

function json(data, status=200, extra={}) {
  return new Response(JSON.stringify(data), {
    status, headers: {"content-type":"application/json; charset=utf-8", ...extra}
  });
}
function b64(s){return btoa(unescape(encodeURIComponent(s))).replace(/=/g,"")}
function unb64(s){try{return decodeURIComponent(escape(atob(s)))}catch{return ""}}
async function hmac(secret, text){
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),
    {name:"HMAC",hash:"SHA-256"},false,["sign"]);
  const sig=await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(text));
  return b64(String.fromCharCode(...new Uint8Array(sig)));
}
async function makeSession(secret){
  const exp=Date.now()+1000*60*60*24*7;
  const body=`admin|${exp}`;
  return `${b64(body)}.${await hmac(secret,body)}`;
}
async function isAdmin(request, env){
  const c=request.headers.get("Cookie")||"";
  const m=c.match(new RegExp(`${COOKIE}=([^;]+)`));
  if(!m) return false;
  const [enc,sig]=m[1].split(".");
  const body=unb64(enc); const parts=body.split("|");
  if(parts.length!==2 || parts[0]!=="admin" || Number(parts[1])<Date.now()) return false;
  const good=await hmac(env.ADMIN_PASSWORD,body);
  return sig===good;
}
function cleanName(v){return String(v||"").trim().slice(0,120)}
function ext(type){
  const map={"image/jpeg":"jpg","image/png":"png","image/webp":"webp","image/avif":"avif"};
  return map[type]||"bin";
}
async function handleAPI(request, env){
  const url=new URL(request.url), path=url.pathname;
  if(request.method==="GET" && path==="/api/products"){
    const q=(url.searchParams.get("q")||"").trim();
    const cat=url.searchParams.get("category")||"";
    const con=url.searchParams.get("condition")||"";
    let sql="SELECT id,name,category,condition,price,city,description,image_key,featured,created_at FROM products WHERE 1=1";
    const args=[];
    if(q){sql+=" AND (name LIKE ? OR description LIKE ? OR city LIKE ?)"; const x=`%${q}%`;args.push(x,x,x)}
    if(cat){sql+=" AND category = ?";args.push(cat)}
    if(con){sql+=" AND condition = ?";args.push(con)}
    sql+=" ORDER BY featured DESC, id DESC LIMIT 100";
    const {results}=await env.DB.prepare(sql).bind(...args).all();
    return json(results.map(p=>({...p,image:p.image_key?`/media/${encodeURIComponent(p.image_key)}`:""})));
  }
  if(request.method==="GET" && path.startsWith("/media/")){
    const key=decodeURIComponent(path.slice(7));
    const obj=await env.IMAGES.get(key);
    if(!obj)return new Response("Not found",{status:404});
    const headers=new Headers();obj.writeHttpMetadata(headers);headers.set("cache-control","public,max-age=31536000,immutable");
    return new Response(obj.body,{headers});
  }
  if(request.method==="POST" && path==="/api/login"){
    const body=await request.json().catch(()=>({}));
    if(!body.password || body.password!==env.ADMIN_PASSWORD)return json({error:"كلمة المرور غير صحيحة"},401);
    const token=await makeSession(env.ADMIN_PASSWORD);
    return json({ok:true},{ "set-cookie":`${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=604800`});
  }
  if(request.method==="POST" && path==="/api/logout"){
    return json({ok:true},{"set-cookie":`${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`});
  }
  if(path==="/api/admin/products"){
    if(!(await isAdmin(request,env)))return json({error:"غير مصرح"},401);
    if(request.method==="GET"){
      const {results}=await env.DB.prepare("SELECT * FROM products ORDER BY id DESC").all();
      return json(results.map(p=>({...p,image:p.image_key?`/media/${encodeURIComponent(p.image_key)}`:""})));
    }
    if(request.method==="POST"){
      const form=await request.formData();
      const name=cleanName(form.get("name")), category=String(form.get("category")||""),
            condition=String(form.get("condition")||""), price=cleanName(form.get("price")),
            city=cleanName(form.get("city")), description=String(form.get("description")||"").slice(0,2000),
            featured=form.get("featured")==="1";
      if(!name || !["غرف نوم","مطابخ"].includes(category) || !["جديد","مستعمل"].includes(condition))
        return json({error:"بيانات المنتج غير مكتملة"},400);
      let imageKey="";
      const file=form.get("image");
      if(file && file instanceof File && file.size){
        if(file.size>MAX_IMAGE)return json({error:"الصورة أكبر من 8MB"},400);
        if(!["image/jpeg","image/png","image/webp","image/avif"].includes(file.type))
          return json({error:"صيغة الصورة غير مدعومة"},400);
        imageKey=`products/${crypto.randomUUID()}.${ext(file.type)}`;
        await env.IMAGES.put(imageKey,file,{httpMetadata:{contentType:file.type}});
      }
      const r=await env.DB.prepare(`INSERT INTO products(name,category,condition,price,city,description,image_key,featured) VALUES(?,?,?,?,?,?,?,?)`)
        .bind(name,category,condition,price,city,description,imageKey,featured?1:0).run();
      return json({ok:true,id:r.meta.last_row_id});
    }
  }
  const del=path.match(/^\/api\/admin\/products\/(\d+)$/);
  if(del && request.method==="DELETE"){
    if(!(await isAdmin(request,env)))return json({error:"غير مصرح"},401);
    const id=Number(del[1]); const p=await env.DB.prepare("SELECT image_key FROM products WHERE id=?").bind(id).first();
    if(!p)return json({error:"المنتج غير موجود"},404);
    if(p.image_key)await env.IMAGES.delete(p.image_key);
    await env.DB.prepare("DELETE FROM products WHERE id=?").bind(id).run();
    return json({ok:true});
  }
  return json({error:"Not found"},404);
}
export default {
 async fetch(request,env,ctx){
   const url=new URL(request.url);
   if(url.pathname.startsWith("/api/") || url.pathname.startsWith("/media/")) return handleAPI(request,env);
   return env.ASSETS.fetch(request);
 }
};